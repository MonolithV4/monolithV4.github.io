# Monolith v3

Private, phone-first fitness tracker.

## v3 additions
- Food and macro calculator/log
- 1,000-entry local starter index of common high-protein foods and variants
- Searchable dropdown via datalist
- Weight input with grams, ounces, pounds, kilograms, or servings
- Macro preview before logging
- Daily calories/protein/carbs/fat totals and goals
- Custom food / package label entries
- Food CSV export
- Logo/header font selector
- Local custom font upload for legally obtained font files such as Fayte or Inktoner

## Important nutrition note
Built-in foods are generic starter values. For branded/packaged foods, use the nutrition label and save a custom food.

## Install
Upload the folder contents to GitHub Pages, Netlify, Cloudflare Pages, or another static host. Open it on your phone and add it to the home screen.
